var imagen = document.getElementById("imagen");
var posInicial = null;
var posFinal = null;

imagen.addEventListener("click", function(event) {
  if (posInicial === null) {
    posInicial = {
      x: event.clientX - imagen.offsetLeft,
      y: event.clientY - imagen.offsetTop
    };
  } else if (posFinal === null) {
    posFinal = {
      x: event.clientX - imagen.offsetLeft,
      y: event.clientY - imagen.offsetTop
    };
    animaRecta(imagen, posInicial.x, posInicial.y, posFinal.x, posFinal.y);
    posInicial = null;
    posFinal = null;
  }
});

function animaRecta(capa, iniciX, iniciY, finalX, finalY, pas) {
  var valorX = iniciX;
  var valorY = iniciY;
  var distX = Math.abs(finalX - iniciX);
  var distY = Math.abs(finalY - iniciY);
  var cami = Math.sqrt(Math.pow(distX, 2) + Math.pow(distY, 2));
  var vel = pas || 1;
  var pasoX = parseInt((finalX - iniciX) / cami * vel);
  var pasoY = parseInt((finalY - iniciY) / cami * vel);

  var interval = setInterval(function() {
    if (valorX === finalX && valorY === finalY) {
      clearInterval(interval);
    } else {
      valorX += pasoX;
      valorY += pasoY;
      capa.style.left = valorX + "px";
      capa.style.top = valorY + "px";
    }
  }, 10);
}
